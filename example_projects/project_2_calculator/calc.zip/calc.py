import sylia
sylia.init([400, 600])

sylia.screen.colour([100, 100, 100])

class Screen:
    def __init__(self, position):
        self.text = ""
        self.position = position
        self.dimensions = [350, 70]
        self.colour = [150, 150, 200]
        self.textColour = [0, 0, 0]
        self.rect = sylia.shape.rectangle(self.position, self.dimensions, self.colour)
        self.textObject = sylia.text.create("arial", 30, self.text, self.position, colour=self.textColour)

    def updateText(self, text):
        self.text = text
        self.textObject = sylia.text.create("arial", 30, self.text, self.position, colour=self.textColour)

    def draw(self):
        sylia.screen.draw(self.rect)
        sylia.screen.draw(self.textObject)

class Button:
    def __init__(self, text, position):
        self.text = text
        self.position = position
        self.dimensions = [80, 60]
        self.colour = [150, 150, 150]
        self.textColour = [0, 0, 0]
        self.rect = sylia.shape.rectangle(self.position, self.dimensions, self.colour)
        self.textObject = sylia.text.create("arial", 20, self.text, self.position, colour=self.textColour)
        self.hold = False

    def getValue(self):
        value = self.value
        return value

    def pressed(self, pressed):
        if(pressed):
            self.colour = [200, 200, 200]
        else:
            self.colour = [150, 150, 150]

        self.rect.colour = self.colour
        
    def update(self):
        mx = sylia.mouse.position()[0]
        my = sylia.mouse.position()[1]
        xmin = self.position[0] - self.dimensions[0]/2
        xmax = self.position[0] + self.dimensions[0]/2
        ymin = self.position[1] - self.dimensions[1]/2
        ymax = self.position[1] + self.dimensions[1]/2

        self.value = None

        mouse_within_button = (mx > xmin and mx < xmax and my > ymin and my < ymax)
        if(sylia.mouse.pressed("left") and mouse_within_button):
            
            if(not self.hold):
                self.value = self.text
                
            self.pressed(True)
            self.hold = True

        elif(not sylia.mouse.pressed("left")):
            self.hold = False
            self.pressed(False)

        else:
            self.pressed(False)

    def draw(self):
        sylia.screen.draw(self.rect)
        sylia.screen.draw(self.textObject)

class Calculator:
    def __init__(self):
        self.current_value = ""
        self.previous_value = 0
        self.op = None

        screen_position = sylia.screen.center()
        screen_position[1] = 85
        self.screen = Screen(screen_position)

        self.buttons = []
        button_start_position = [65, 200]
        button_names = [
            ["%", "CE", "C", "DEL"], #Row 1
            ["1/x", "x^2", "root(x)", "/"], #Row 2
            ["7", "8", "9", "X"], #Row 3
            ["4", "5", "6", "-"], #Row 4
            ["3", "2", "1", "+"], #Row 5
            ["+/-", "0", ".", "="] #Row 6
        ]

        pos_x = button_start_position[0]
        pos_y = button_start_position[1]
        x_gap = 90
        y_gap = 70

        for button_row in button_names:
            pos_x = button_start_position[0]
            for name in button_row:
                self.buttons.append(Button(name, [pos_x, pos_y]))
                pos_x += x_gap
            
            pos_y += y_gap

    def draw(self):
        self.screen.draw()
    
    def isOp(self, value):
        if(value in ['+', '-', 'X', '/']):
            return True
        else:
            return False

    def update(self):
        for button in self.buttons:
            button.draw()
            button.update()
            value = button.getValue()
            if(value):
                if(value.isdigit() or value == '.'):
                    self.current_value += value
                    self.screen.updateText(self.current_value)
                elif(self.isOp(value)):
                    self.previous_value = float(self.current_value)
                    self.op = value
                    self.screen.updateText('')
                    self.current_value = ''
                elif(value == '='):
                    if(self.op == '+'):
                        self.previous_value += float(self.current_value)
                    elif(self.op == '-'):
                        self.previous_value -= float(self.current_value)
                    elif(self.op == 'X'):
                        self.previous_value *= float(self.current_value)
                    elif(self.op == '/'):
                        self.previous_value /= float(self.current_value)
                    self.current_value = str(self.previous_value)
                    self.screen.updateText(self.current_value)
                elif(value == 'C'):
                    self.current_value = ''
                    self.screen.updateText('')
                elif(value == 'CE'):
                    self.previous_value = 0
                    self.current_value = ''
                    self.screen.updateText('')
                elif(value == 'DEL'):
                    self.current_value = self.current_value[:-1]
                    self.screen.updateText(self.current_value)
                elif(value == '+/-'):
                    if '-' not in self.current_value:
                        self.sign = False
                        self.current_value = '-' + self.current_value
                    else:
                        self.sign = True
                        self.current_value = self.current_value[1:]
                    self.screen.updateText(self.current_value)
                elif(value == '1/x'):
                    self.previous_value = 1/float(self.current_value)
                    self.current_value = str(self.previous_value)
                    self.screen.updateText(self.current_value)
                elif(value == 'x^2'):
                    self.previous_value = float(self.current_value)**2
                    self.current_value = str(self.previous_value)
                    self.screen.updateText(self.current_value)
                elif(value == 'root(x)'):
                    self.previous_value = float(self.current_value)**0.5
                    self.current_value = str(self.previous_value)
                    self.screen.updateText(self.current_value)
                elif(value == '%'):
                    if(self.op == '+'):
                        self.previous_value += (float(self.current_value)/100*self.previous_value)
                    elif(self.op == '-'):
                        self.previous_value -= (float(self.current_value)/100*self.previous_value)
                    elif(self.op == 'X'):
                        self.previous_value *= (float(self.current_value)/100)
                    elif(self.op == '/'):
                        self.previous_value /= (float(self.current_value)/100)

                    self.current_value = str(self.previous_value)
                    self.screen.updateText(self.current_value)
                

calc = Calculator()

while(sylia.running()):
    calc.draw()
    calc.update()
