import sylia
import time

sylia.init([800, 600])

class HitBox:
    def __init__(self, position, width, height):
        self.position = position
        self.width = width
        self.height = height

    @staticmethod
    def checkCollide(hitbox1, hitbox2):

        hw1 = hitbox1.width/2
        hw2 = hitbox2.width/2
        hh1 = hitbox1.height/2
        hh2 = hitbox2.height/2

        min_x1 = hitbox1.position[0] - hw1
        max_x1 = hitbox1.position[0] + hw1
        min_y1 = hitbox1.position[1] - hh1
        max_y1 = hitbox1.position[1] + hh1

        min_x2 = hitbox2.position[0] - hw2
        max_x2 = hitbox2.position[0] + hw2
        min_y2 = hitbox2.position[1] - hh2
        max_y2 = hitbox2.position[1] + hh2

        if(max_x1 > min_x2 and min_x1 < max_x2):
            if(max_y1 > min_y2 and min_y1 < max_y2):
                return True
        return False  

class Timer:
    def __init__(self, delay, offset=0):
        self.delay = delay
        self.start_time = 0
        self.firstRun = False
        self.offset = offset

    def reset(self):
        self.firstRun = False

    def setDelay(self, delay):
        self.delay = delay

    def start(self):
        #Allow for a offset for first run time (this allows us to have timers repeat at same interval with different offset)
        if(not self.firstRun):
            self.start_time = time.time() + self.offset
            self.firstRun = True
            return

        self.start_time = time.time()

    def check(self):
        # Make sure we have started first
        if(not self.firstRun):
            return False

        current_time = time.time()

        if(current_time - self.start_time > self.delay):
            return True
        return False

class Player:
    def __init__(self):
        self.position = sylia.screen.center()
        self.position[1] = 450
        self.radius = 50
        self.colour = [200, 200, 0]
        self.triangle = sylia.shape.triangle(self.position, self.radius, self.colour)
        self.triangle.setRotation(180)
        self.speed = 10
        self.hitbox = HitBox(self.position, 50, 50)

    def handleMovement(self):
        
        if(sylia.key.pressed('left')):
            self.position[0] -= self.speed
        elif(sylia.key.pressed('right')):
            self.position[0] += self.speed

        #Check for boundary
        if(self.position[0] + self.radius > sylia.screen.width()):
            self.position[0] = sylia.screen.width() - self.radius
        elif(self.position[0] - self.radius < 0):
            self.position[0] = 0 + self.radius

        self.triangle.setPosition(self.position)

    def reset(self):
        self.position = sylia.screen.center()
        self.position[1] = 450
        self.hitbox = HitBox(self.position, 50, 50)

    def getHitBox(self):
        return self.hitbox 

    def update(self):
        self.handleMovement()

    def draw(self):
        sylia.screen.draw(self.triangle)

class Enemy:
    def __init__(self, start_position, speed):
        self.position = start_position
        self.dimensions = [50, 50]
        self.colour = [200, 50, 50]
        self.rectangle = sylia.shape.rectangle(self.position, self.dimensions, self.colour)
        self.speed = speed
        self.hitbox = HitBox(self.position, 50, 50)

    def handleAI(self):
        self.position[1] += self.speed
        
        self.rectangle.setPosition(self.position)

    def checkOutOfBounds(self):
        # We add the dimensions of the enemy multiplied by 2 just to give some extra distance before enemy disappears
        # so that we don't see the enemy vanish in the game (it happens offscreen)
        if(self.position[1] > sylia.screen.height() + self.dimensions[1]*2):
            return True
        return False

    def getHitBox(self):
        return self.hitbox 

    def update(self):
        self.handleAI()

    def draw(self):
        sylia.screen.draw(self.rectangle)

class EnemyHandler:
    def __init__(self):
        self.enemies = []

    def register(self, enemy):
        self.enemies.append(enemy)

    def reset(self):
        self.enemies.clear()

    def update(self, player, game):
        for enemy in self.enemies:
            enemy.update()
            enemy.draw()
        
        for enemy in self.enemies:
            #Check for player collisions
            if(HitBox.checkCollide(enemy.getHitBox(), player.getHitBox())):
                game.loseLife()
                self.enemies.remove(enemy)

            if(enemy.checkOutOfBounds()):
                self.enemies.remove(enemy)
            del enemy

class GameHandler:
    def __init__(self):
        self.lives = 3
        self.score = 0
        self.gameOver = False
        self.timer = Timer(0.5)
        self.timer.start()

    def getScore(self):
        return self.score

    def getLives(self):
        return self.lives

    def addScore(self, score):
        self.score += score

    def update(self):
        if(self.timer.check()):
            self.addScore(10)
            self.timer.start()

    def isGameOver(self):
        return self.gameOver

    def reset(self):
        self.lives = 3
        self.score = 0
        self.gameOver = False

    def loseLife(self):
        self.lives -= 1

        if(self.lives < 0):
            self.gameOver = True

class HUD:
    def __init__(self):
        self.base = sylia.shape.rectangle([sylia.screen.center()[0], 550], [800, 100], (100, 100, 100))
        self.scoreText = sylia.text.create('arial', 20, "Score:", [450, 550])
        self.livesText = sylia.text.create('arial', 20, "Lives:", [150, 550])
        self.scoreCounter = sylia.text.create('arial', 20, "{}".format(0), [500, 550])
        self.livesCounter = sylia.text.create('arial', 20, "{}".format(3), [200, 550])
        self.lives = 3
        self.score = 0

    def update(self, game):
        if(self.score != game.getScore()):
            self.score = game.getScore()
            self.scoreCounter = sylia.text.create('arial', 20, "{}".format(game.getScore()), [500, 550])

        if(self.lives != game.getLives()):
            self.lives = game.getLives()
            self.livesCounter = sylia.text.create('arial', 20, "{}".format(game.getLives()), [200, 550])

    def draw(self):
        sylia.screen.draw(self.base)
        sylia.screen.draw(self.scoreText)
        sylia.screen.draw(self.livesText)
        sylia.screen.draw(self.scoreCounter)
        sylia.screen.draw(self.livesCounter)

class EnemySpawner:
    def __init__(self, position, delay, offset):
        self.start_delay = delay
        self.start_enemy_speed = 5
        
        self.delay = delay
        self.enemy_speed = 5
        self.timer = Timer(delay, offset=offset)
        self.upgrade_timer = Timer(6)
        self.num_spawned_entities = 0
        self.position = position
        self.rectangle = sylia.shape.rectangle(self.position, [20, 20], (255, 200, 200))
        self.timer.start() # Start the timers
        self.upgrade_timer.start()

    def reset(self):
        self.timer.reset()
        self.upgrade_timer.reset()
        self.timer.start() # Start the timers
        self.upgrade_timer.start()

        self.enemy_speed = self.start_enemy_speed
        self.delay = self.start_delay

    def update(self):
        if(self.upgrade_timer.check()):
            self.delay -= 0.2
            if(self.delay < 1):
                self.delay = 1

            self.enemy_speed += 1
            self.upgrade_timer.setDelay(self.delay)
            self.upgrade_timer.start()

        if(self.timer.check()):
            enemy = Enemy(list(self.position), self.enemy_speed)
            self.timer.start()
            self.num_spawned_entities += 1
            return enemy
        return None

    # USED FOR DEBUGGING ONLY
    def debug_draw(self):
        sylia.screen.draw(self.rectangle)

player = Player()
enemy_handler = EnemyHandler()
game_handler = GameHandler()
hud = HUD()

spawners = []
spawners.append(EnemySpawner([50, -100], 5, 10.5))
spawners.append(EnemySpawner([100, -100], 3, 0))
spawners.append(EnemySpawner([150, -100], 5, 12.5))
spawners.append(EnemySpawner([200, -100], 3, 5))
spawners.append(EnemySpawner([250, -100], 5, 14.5))
spawners.append(EnemySpawner([300, -100], 3, 0))
spawners.append(EnemySpawner([350, -100], 5, 16.5))
spawners.append(EnemySpawner([400, -100], 3, 5))
spawners.append(EnemySpawner([450, -100], 5, 18.5))
spawners.append(EnemySpawner([500, -100], 3, 0))
spawners.append(EnemySpawner([550, -100], 5, 20.5))
spawners.append(EnemySpawner([600, -100], 3, 5))
spawners.append(EnemySpawner([650, -100], 5, 22.5))
spawners.append(EnemySpawner([700, -100], 3, 0))
spawners.append(EnemySpawner([750, -100], 5, 24.5))

while(sylia.running()):

    if(game_handler.isGameOver()):
        for spawner in spawners:
            spawner.reset()
        
        enemy_handler.reset()
        game_handler.reset()
        player.reset()


    # Spawners will check to see if they can spawn and will return spawned enemy if they do
    for spawner in spawners:
        enemy = spawner.update()
        if(enemy):
            enemy_handler.register(enemy)

    enemy_handler.update(player, game_handler)
    game_handler.update()
    hud.update(game_handler)

    player.update()
    player.draw()
    hud.draw()