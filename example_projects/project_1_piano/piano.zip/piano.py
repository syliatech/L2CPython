import sylia
sylia.init([250, 150])

sylia.setBackgroundColour([200, 50, 50])

piano_starting_position = sylia.screenCenter()
text = sylia.text.create('Arial', 30, "The Power", [piano_starting_position[0], 20], colour=(255, 255, 255))

piano_starting_position[0] -= 105
piano_starting_position[1] += 15


notes = [
    sylia.sound.load('piano/c3.ogg'),
    sylia.sound.load('piano/d3.ogg'),
    sylia.sound.load('piano/e3.ogg'),
    sylia.sound.load('piano/f3.ogg'),
    sylia.sound.load('piano/g3.ogg'),
    sylia.sound.load('piano/a3.ogg'),
    sylia.sound.load('piano/b3.ogg'),
    sylia.sound.load('piano/c4.ogg')
]

sharp_notes = [
    sylia.sound.load('piano/c-3.ogg'),
    sylia.sound.load('piano/d-3.ogg'),
    sylia.sound.load('piano/f-3.ogg'),
    sylia.sound.load('piano/g-3.ogg'),
    sylia.sound.load('piano/a-3.ogg')
]

key_names = [
    'q',
    'w',
    'e',
    'r',
    't',
    'y',
    'u',
    'i'
]

sharp_key_names = [
    '2',
    '3',
    '5',
    '6',
    '7'
]

offset_list = [
    30*0,
    30*1,
    30*2,
    30*3,
    30*4,
    30*5,
    30*6,
    30*7
]

sharp_offset_list = [
    30*0 + 15,
    30*1 + 15,
    30*3 + 15,
    30*4 + 15,
    30*5 + 15
]

def play_note(key, hold, note, channel, sharp=False):

    if(sharp):
        channel += 7

    if(sylia.key.pressed(key)):
        if(hold == False):
            sylia.sound.play(note, channel_number=channel)
            hold = True
    else:
        hold = False

    # Need to return that status of hold so it can be updated for each key
    return hold

def make_key(keyname, offset, note, sharp=False):

    if(sharp):
        position = [piano_starting_position[0] + offset, piano_starting_position[1] - 20]
        dimensions = [15, 60]
        return [keyname, sylia.shape.rectangle(position, dimensions, [50, 50, 50]), False, note]
    else:
        position = [piano_starting_position[0] + offset, piano_starting_position[1]]
        dimensions = [25, 100]
        return [keyname, sylia.shape.rectangle(position, dimensions, [200, 200, 200]), False, note]

def key_pressed(key, sharp=False):
    
    if(sharp):
        if(sylia.key.pressed(key[0])):
            key[1].colour = [0, 0, 0]
        else:
            key[1].colour = [50, 50, 50]
    
    else:
        if(sylia.key.pressed(key[0])):
            key[1].colour = [155, 155, 155]
        else:
            key[1].colour = [200, 200, 200]

def mute():

    if(sylia.key.pressed('space')):
        sylia.sound.stopAll()

keys = []
for i in range(len(offset_list)):
    offset = offset_list[i]
    key_name = key_names[i]
    note = notes[i]
    keys.append(make_key(key_name, offset, note))

sharps = []
for i in range(len(sharp_offset_list)):
    offset = sharp_offset_list[i]
    key_name = sharp_key_names[i]
    note = sharp_notes[i]
    sharps.append(make_key(key_name, offset, note, sharp=True))


while(sylia.running()):

    sylia.draw(text)

    for i in range(len(keys)):
        key = keys[i]
        key_pressed(key)
        sylia.draw(key[1])
        key[2] = play_note(key[0], key[2], key[3], i)

    for i in range(len(sharps)):
        key = sharps[i]
        key_pressed(key, sharp=True)
        sylia.draw(key[1])
        key[2] = play_note(key[0], key[2], key[3], i, sharp=True)

    mute()